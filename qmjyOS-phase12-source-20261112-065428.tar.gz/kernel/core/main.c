#include "serial.h"
#include "idt.h"
#include "pic.h"
#include "timer.h"
#include "task.h"
#include "paging.h"
#include "memory.h"
#include "../../fs/core/fs_init.h"
#include "../../fs/qfs/qfs.h"
#include "../../fs/partition/mbr.h"
#include "../../drivers/block/ide_pio.h"
#include <stdint.h>

extern void gdt_load_and_reload_cs(const void *gdtr);

// 分配 16KB 内核栈，用于 Ring 3 中断时切换回来
uint8_t kernel_stack[16384] __attribute__((aligned(16)));
uint64_t kernel_stack_top;

// TSS 结构体 (64位)
struct tss_entry {
    uint32_t reserved0;
    uint64_t rsp0;       // 内核栈指针
    uint64_t rsp1;
    uint64_t rsp2;
    uint64_t reserved1;
    uint64_t ist[7];
    uint64_t reserved2;
    uint16_t reserved3;
    uint16_t iomap_base;
} __attribute__((packed));

struct tss_entry tss;

// GDT 表 (7个条目)
// 0: null
// 1: kernel code (0x08)
// 2: kernel data (0x10)
// 3: user data   (0x18)  <- 注意顺序
// 4: user code   (0x20)
// 5: TSS low     (0x28)
// 6: TSS high
uint64_t my_gdt[7];

void init_gdt_and_tss() {
    // 1. 初始化 TSS
    uint8_t *p = (uint8_t *)&tss;
    for (int i = 0; i < sizeof(tss); i++) p[i] = 0;

    kernel_stack_top = (uint64_t)kernel_stack + sizeof(kernel_stack);
    tss.rsp0 = kernel_stack_top; // 设置 Ring 3->0 切换时的内核栈
    tss.iomap_base = sizeof(tss);

    // 2. 填充 GDT
    my_gdt[0] = 0;
    // Kernel Code: 0x08
    my_gdt[1] = 0x00AF9A000000FFFF;
    // Kernel Data: 0x10
    my_gdt[2] = 0x00CF92000000FFFF;
    // User Data: 0x18 (DPL=3)
    my_gdt[3] = 0x00CFF2000000FFFF;
    // User Code: 0x20 (DPL=3, L=1)
    my_gdt[4] = 0x00AFFA000000FFFF;

    // 3. 构造 TSS 描述符 (类型必须为 0x9，即 0x89)
    uint64_t base = (uint64_t)&tss;
    uint64_t limit = sizeof(tss) - 1;
    uint64_t low = (limit & 0xFFFF) | ((base & 0xFFFFFF) << 16) |
                   (0x89ULL << 40) | (((limit >> 16) & 0xF) << 48) |
                   (((base >> 24) & 0xFF) << 56);
    uint64_t high = base >> 32;
    my_gdt[5] = low;
    my_gdt[6] = high;

    // 4. 加载 GDT 和 TSS
    struct { uint16_t limit; uint64_t base; } __attribute__((packed)) gdtr;
    gdtr.limit = 7 * 8 - 1;
    gdtr.base = (uint64_t)my_gdt;
    gdt_load_and_reload_cs(&gdtr);
    __asm__ volatile("ltr %0" :: "r"((uint16_t)0x28)); // TSS 选择子
}

// 用户态测试代码：尝试执行特权指令 cli
void user_code(void) {
    __asm__ volatile("cli");
    while(1);
}

// 从 Ring 0 跳转到 Ring 3
void enter_user_mode(void (*user_func)(void)) {
    static uint64_t user_stack[1024];
    uint64_t *sp = &user_stack[1024];
    sp = (uint64_t *)((uint64_t)sp & ~0xF); // 16字节对齐
    uint64_t user_rsp = (uint64_t)sp;

    // 严格按顺序压入 iretq 需要的 5 个值
    // SS = 0x18 | 3 = 0x1B (用户数据段，RPL=3)
    *(--sp) = 0x1B;
    // 先计算用户态 RSP，再压入，避免同一表达式中修改并读取 sp。
    *(--sp) = user_rsp;
    // RFLAGS = 0x202 (IF=1, bit1=1)
    *(--sp) = 0x202;
    // CS = 0x20 | 3 = 0x23 (用户代码段，RPL=3)
    *(--sp) = 0x23;
    // RIP = 用户函数入口
    *(--sp) = (uint64_t)user_func;

    __asm__ volatile(
        "mov %0, %%rsp\n"
        "iretq\n"
        :: "r"(sp) : "memory"
    );
}

extern char __kernel64_start, __kernel64_end;



/* -------------------------------------------------
 * Ring 3 isolated address space test
 * ------------------------------------------------- */

#define RING3_CODE_VA  0x0000000040000000ULL
#define RING3_STACK_VA 0x0000000040001000ULL

extern void ring3_enter(uint64_t user_rsp, uint64_t user_rip);
extern char user_blob_start[];
extern char user_blob_end[];

static void ring3_zero_page(uint64_t physical)
{
    volatile uint64_t *p = (volatile uint64_t *)(uintptr_t)physical;
    for (size_t i = 0; i < MM_PAGE_SIZE / sizeof(uint64_t); ++i)
        p[i] = 0;
}

/*
 * Called from syscall_entry on the TSS.RSP0 kernel stack.
 * RAX=1 is the Ring 3 test-exit request.
 */
void ring3_syscall_handler(uint64_t syscall_number)
{
    if (syscall_number == 1) {
        serial_puts("[Ring 3] System call received successfully.\n");
        serial_puts("[Ring 3] Returning to Ring 0.\n");
    } else {
        serial_puts("[Ring 3] Unknown system call.\n");
    }
}

static int ring3_prepare_and_run(void)
{
    uint64_t code_pa = 0;
    uint64_t stack_pa = 0;
    uint64_t query_pa = 0;
    uint64_t query_flags = 0;
    int code_mapped = 0;
    int stack_mapped = 0;
    int activated = 0;
    int result = -1;

    const size_t blob_size =
        (size_t)(user_blob_end - user_blob_start);

    serial_puts("\n[Ring 3] Preparing isolated user address space.\n");

    if (!vm_nx_enabled()) {
        serial_puts("[Ring 3] ERROR: CPU NX support or EFER.NXE unavailable.\n");
        return -1;
    }

    if (blob_size == 0 || blob_size > MM_PAGE_SIZE) {
        serial_puts("[Ring 3] ERROR: user code size invalid.\n");
        return -1;
    }

    /*
     * Rebuild clean inactive page tables after the paging self-test.
     */
    if (vm_init() != VM_OK) {
        serial_puts("[Ring 3] ERROR: vm_init failed.\n");
        return -1;
    }

    if (mm_alloc_page(&code_pa) != MM_OK) {
        serial_puts("[Ring 3] ERROR: cannot allocate user code page.\n");
        return -1;
    }

    if (mm_alloc_page(&stack_pa) != MM_OK) {
        serial_puts("[Ring 3] ERROR: cannot allocate user stack page.\n");
        mm_free_page(code_pa);
        return -1;
    }

    ring3_zero_page(code_pa);
    ring3_zero_page(stack_pa);

    /* Copy the position-independent user program to its own page. */
    {
        volatile uint8_t *dst = (volatile uint8_t *)(uintptr_t)code_pa;
        const uint8_t *src = (const uint8_t *)user_blob_start;

        for (size_t i = 0; i < blob_size; ++i)
            dst[i] = src[i];
    }

    /*
     * User code: USER, read-only, executable.
     * User stack: USER, writable, NX.
     */
    if (vm_map_page(RING3_CODE_VA, code_pa, VM_USER) != VM_OK) {
        serial_puts("[Ring 3] ERROR: code mapping failed.\n");
        goto cleanup;
    }
    code_mapped = 1;

    if (vm_map_page(RING3_STACK_VA, stack_pa,
                    VM_USER | VM_WRITE | VM_NO_EXECUTE) != VM_OK) {
        serial_puts("[Ring 3] ERROR: stack mapping failed.\n");
        goto cleanup;
    }
    stack_mapped = 1;

    /* Verify user code mapping. */
    if (vm_query_page(RING3_CODE_VA, &query_pa, &query_flags) != VM_OK ||
        query_pa != code_pa ||
        !(query_flags & VM_USER) ||
        (query_flags & VM_WRITE) ||
        (query_flags & VM_NO_EXECUTE)) {
        serial_puts("[Ring 3] ERROR: code permissions invalid.\n");
        goto cleanup;
    }

    /* Verify user stack mapping. */
    if (vm_query_page(RING3_STACK_VA, &query_pa, &query_flags) != VM_OK ||
        query_pa != stack_pa ||
        !(query_flags & VM_USER) ||
        !(query_flags & VM_WRITE) ||
        !(query_flags & VM_NO_EXECUTE)) {
        serial_puts("[Ring 3] ERROR: stack permissions invalid.\n");
        goto cleanup;
    }

    /* Verify the kernel identity mapping remains supervisor-only. */
    if (vm_query_page(0x00200000ULL, &query_pa, &query_flags) != VM_OK ||
        (query_flags & VM_USER)) {
        serial_puts("[Ring 3] ERROR: kernel mapping is user-accessible.\n");
        goto cleanup;
    }

    serial_puts("[Ring 3] User code page: RX, U/S=1.\n");
    serial_puts("[Ring 3] User stack page: RW/NX, U/S=1.\n");
    serial_puts("[Ring 3] Kernel identity mapping: supervisor-only.\n");

    /*
     * All mappings and permissions are ready.
     * vm_activate switches CR3 only after the kernel identity map exists.
     */
    if (vm_activate() != VM_OK) {
        serial_puts("[Ring 3] ERROR: CR3 activation failed.\n");
        goto cleanup;
    }
    activated = 1;

    serial_puts("[Ring 3] CR3 activated.\n");
    serial_puts("[Ring 3] Entering CPL3.\n");

    /*
     * The user program executes:
     *     mov $1, %eax
     *     int $0x80
     *
     * syscall_entry restores the saved Ring 0 stack and returns here.
     */
    ring3_enter(RING3_STACK_VA + MM_PAGE_SIZE - 16,
                RING3_CODE_VA);

    serial_puts("[Ring 3] Returned to Ring 0 successfully.\n");
    result = 0;

cleanup:
    /*
     * Once CR3 is active, vm_unmap_page invalidates the affected TLB entry.
     * Keep the active page-table root; the scheduler continues using it.
     */
    if (stack_mapped) {
        if (vm_unmap_page(RING3_STACK_VA) != VM_OK) {
            serial_puts("[Ring 3] WARNING: stack unmap failed.\n");
            result = -1;
        }
    }

    if (code_mapped) {
        if (vm_unmap_page(RING3_CODE_VA) != VM_OK) {
            serial_puts("[Ring 3] WARNING: code unmap failed.\n");
            result = -1;
        }
    }

    if (stack_pa && mm_free_page(stack_pa) != MM_OK) {
        serial_puts("[Ring 3] WARNING: stack page release failed.\n");
        result = -1;
    }

    if (code_pa && mm_free_page(code_pa) != MM_OK) {
        serial_puts("[Ring 3] WARNING: code page release failed.\n");
        result = -1;
    }

    (void)activated;
    return result;
}


static void serial_put_hex32(uint32_t value) {
    static const char digits[] = "0123456789ABCDEF";
    char out[11] = "0x00000000";
    for (int i = 0; i < 8; ++i) {
        out[9 - i] = digits[value & 0xFU];
        value >>= 4;
    }
    out[10] = '\0';
    serial_puts(out);
}

static void serial_dump_multiboot_map(uint32_t magic, uint32_t info_addr) {
    serial_puts("[MM DEBUG] magic=");
    serial_put_hex32(magic);
    serial_puts(" info=");
    serial_put_hex32(info_addr);
    serial_puts("\\n");

    if (!info_addr || (uint64_t)info_addr + 88 > (1ULL << 30)) {
        serial_puts("[MM DEBUG] info address outside mapped range.\\n");
        return;
    }

    const volatile uint32_t *info =
        (const volatile uint32_t *)(uintptr_t)info_addr;

    uint32_t flags = info[0];
    uint32_t mmap_length = info[11];
    uint32_t mmap_addr = info[12];

    serial_puts("[MM DEBUG] flags=");
    serial_put_hex32(flags);
    serial_puts(" mmap_addr=");
    serial_put_hex32(mmap_addr);
    serial_puts(" mmap_length=");
    serial_put_hex32(mmap_length);
    serial_puts("\\n");

    if (!(flags & (1U << 6)) || !mmap_addr || !mmap_length ||
        (uint64_t)mmap_addr + mmap_length > (1ULL << 30)) {
        serial_puts("[MM DEBUG] Multiboot mmap header invalid.\\n");
        return;
    }

    const volatile uint32_t *entry =
        (const volatile uint32_t *)(uintptr_t)mmap_addr;
    uint32_t count = mmap_length / 24;
    if (count > 4) count = 4;

    for (uint32_t i = 0; i < count; ++i) {
        const volatile uint32_t *e =
            (const volatile uint32_t *)(uintptr_t)(mmap_addr + i * 24);

        serial_puts("[MM DEBUG] entry ");
        serial_put_hex32(i);
        serial_puts(" size=");
        serial_put_hex32(e[0]);
        serial_puts(" base_hi=");
        serial_put_hex32(e[2]);
        serial_puts(" base_lo=");
        serial_put_hex32(e[1]);
        serial_puts(" len_hi=");
        serial_put_hex32(e[4]);
        serial_puts(" len_lo=");
        serial_put_hex32(e[3]);
        serial_puts(" type=");
        serial_put_hex32(e[5]);
        serial_puts("\\n");
    }
    (void)entry;
}


/* -------------------------------------------------
 * IDE + MBR + QFS storage initialization
 * Uses the secondary IDE device to avoid modifying
 * the QBoot system disk.
 * ------------------------------------------------- */

static void storage_init(void)
{
    qm_partition_t partitions[4];
    qm_u32_t partition_count = 0;
    qm_u32_t i;
    int result;

    serial_puts("\n[Storage] Initializing IDE block devices.\n");

    result = qm_ide_pio_init();

    if (result != 0) {
        serial_puts("[Storage] IDE initialization failed.\n");
        return;
    }

    serial_puts("[Storage] IDE controller initialized.\n");

    result = qm_mbr_scan(
        QM_IDE_PRIMARY_SLAVE,
        partitions,
        4,
        &partition_count
    );

    if (result != 0) {
        serial_puts("[Storage] Cannot read secondary disk MBR.\n");
        return;
    }

    if (partition_count == 0) {
        serial_puts("[Storage] No partition found on secondary disk.\n");
        return;
    }

    serial_puts("[Storage] MBR partition table detected.\n");

    for (i = 0; i < partition_count; ++i) {
        /*
         * Normal boot only mounts standard QFS partitions.
         * The dedicated QFS test partition type 0x7F is ignored.
         * Normal boot must never format a disk automatically.
         */
        if (partitions[i].type != 0x83U) {
            serial_puts("[Storage] Skipping non-QFS partition.\n");
            continue;
        }

        result = qfs_mount_at(&partitions[i], "/disk");

        if (result == VFS_OK) {
            serial_puts("[Storage] QFS mounted at /disk.\n");
            return;
        }
    }

    serial_puts("[Storage] No valid QFS partition found.\n");
    serial_puts("[Storage] Disk was NOT formatted or modified.\n");
}

void main(uint32_t multiboot_magic, uint32_t multiboot_info_addr) {
    serial_init();
    if (fs_init() == 0) {
        serial_puts("[FS] VFS initialized.\n");
        serial_puts("[FS] RAMFS mounted as root filesystem.\n");
    } else {
        serial_puts("[FS] ERROR: filesystem initialization failed.\n");
    }
    serial_puts("Hello, x86_64 kernel!\n");
    serial_dump_multiboot_map(multiboot_magic, multiboot_info_addr);

    int mm_status = mm_init_from_multiboot(multiboot_magic, multiboot_info_addr,
        (uint64_t)(uintptr_t)&__kernel64_start, (uint64_t)(uintptr_t)&__kernel64_end);
    if (mm_status == MM_OK) {
        serial_puts("Physical page allocator: initialized from Multiboot mmap.\n");
        if (mm_self_test() == MM_OK) {
            serial_puts("Physical page allocator self-test: PASS (alloc/free/double-free).\n");
        } else {
            serial_puts("Physical page allocator self-test: FAIL.\n");
        }
    } else {
        serial_puts("[MM DEBUG] mm_init_from_multiboot status=");
        serial_put_hex32((uint32_t)mm_status);
        serial_puts("\n");
        serial_puts("Physical page allocator: unavailable (Multiboot map validation failed).\n");
        serial_puts("Physical page allocator self-test: SKIPPED (allocator unavailable).\n");
    }

    storage_init();

    if (vm_self_test() == 0) {
        serial_puts("Paging manager self-test: PASS (inactive page tables).\n");
    } else {
        serial_puts("Paging manager self-test: FAIL.\n");
    }

    pic_remap();
    idt_init();
    timer_init(100);

    init_gdt_and_tss();

    serial_puts("GDT and TSS initialized.\n");

    /*
     * Run the isolated Ring 3 test before starting the cooperative
     * Ring 0 scheduler. The scheduler itself remains intact.
     */
    if (ring3_prepare_and_run() == 0) {
        serial_puts("[Ring 3] Basic privilege transition: PASS.\n");
    } else {
        serial_puts("[Ring 3] Test did not complete successfully.\n");
    }

    task_init();
    serial_puts("Starting cooperative Ring 0 scheduler.\n");
    __asm__ volatile("sti" ::: "memory");
    task_start();
}
